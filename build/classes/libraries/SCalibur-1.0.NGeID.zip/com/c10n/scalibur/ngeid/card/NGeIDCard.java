/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.card;

import java.io.File;
import java.util.Collection;

import javax.smartcardio.Card;
import javax.smartcardio.CardException;
import javax.smartcardio.CardTerminal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.c10n.cvcert.CVCertificate;
import com.c10n.scalibur.ChannelException;
import com.c10n.scalibur.PacePinType;
import com.c10n.scalibur.SCalibur;
import com.c10n.scalibur.SCaliburException;
import com.c10n.scalibur.card.AbstractCard;
import com.c10n.scalibur.card.BasePin;
import com.c10n.scalibur.card.pin.PinCallback;
import com.c10n.scalibur.card.pin.PinCallback.PinValue;
import com.c10n.scalibur.ngeid.card.EIdRequest.Address;
import com.c10n.scalibur.ngeid.profile.NGeIDProfile;
import com.c10n.scalibur.tki.AbstractTerminalKey;
import com.c10n.scalibur.tki.TkiException;
import com.c10n.scalibur.tr3110.PaConfig;
import com.c10n.utilities.coder.Hex;

/**
 * The class NGeIDCard is the {@link com.c10n.scalibur.card.CardRealization} of the Nigerian eID Card.
 * It uses {@link NGeIDProfile} as low level
 * interface to an Nigerian eID Card, while it offers a convenient and rather
 * save way to perform the eID operations, the Nigerian eID Card permits. 
 * To collect user-credentials, implementations of 
 * {@link com.c10n.scalibur.card.Callback} are used. 
 * If a method is invoked, which requires card communication, a CardTerminal has to be
 * specified beforehand. This can be achieved either by invoking the constructor {@link #NGeIDCard(CardTerminal)} 
 * or by invoking {@link #setReader(CardTerminal)}. 
 * Note, that NGeIDCard does not work with CardTerminal's, which are from 
 * Oracle's implementation of SmartCard IO. We suggest to use JNASmartCardIO as a
 * supplement. Note, that there are three examples in the example directory of SCalibur,
 * which show how to use NGeIDCard. These examples are PinHandling_CardLayer and
 * EIDRead_CardLayer (both in NGeIDExamples) and the Offline Terminal Example 
 * Application.
 *  
 * @see NGeIDProfile
 * @see com.c10n.scalibur.card.Callback
 *
 */
public class NGeIDCard extends AbstractCard {
	static final Logger logger = LoggerFactory.getLogger(NGeIDCard.class); 
	
	NGeIDProfile profile = new NGeIDProfile();
	
	/**
	 * Constructor, which calls {@link #setReader(CardTerminal)}. Throws a ChannelException, 
	 * if provided CardTerminal is one of Oracle's SmartCard IO, which has various open issues.
	 * Better use JNASmartCardIO. A list of JNASmartCardIO terminals can be read from
	 * {@link SCalibur#getTerminalFactory()}.
	 * Also throws a ChannelException, if connecting to the terminal fails.
	 * 
	 * @param terminal the terminal to set.
	 * @throws ChannelException
	 * @see SCalibur#getTerminalFactory()
	 */
	public NGeIDCard(CardTerminal terminal) throws ChannelException {
		super();
		setReader(terminal);
	}

	public NGeIDCard() {
		super();
	}

	/**
	 * gives access to the underlying Profile Layer Implementation of the Nigerian
	 * eID Card. Please check the manuals section on Profile Layer before starting
	 * to use it!
	 */
	public NGeIDProfile getProfile() {
		return profile;
	}
	
	/**
	 * Checks, if the provided CardTerminal contains a smart card, which is 
	 * compatible to the Nigerian eID Card. If it is the case, it returns true; 
	 * otherwise it returns false. If the check fails, false is returned.
	 * @param terminal the CardTerminal to check
	 * @return true if the CardTerminal contains an Nigerian eID Card (or a 
	 * compatible one), false otherwise.
	 */
	public static boolean isCompatibleCardContainedInReader(CardTerminal terminal){
		Card card=null;
		boolean result=false;
		try{
			card = terminal.connect("*");
			NGeIDProfile lProfile = new NGeIDProfile(card);
			card.beginExclusive();
			result = lProfile.isInstance();
			
		} catch (CardException e) {
			result = false;
		} finally {
			try {
				// Fairly save, even if we do not reset the card here, since 
				// no pin or else was submitted:
				SCalibur.disconnectCard(card, false);
			} catch (CardException e) {
				logger.debug("unable to disconnect", e);
			}
			card = null;
		}
		return result;
	}
	
	/**
	 * Reads the ChipId of the Card. Requires card communication.
	 * @return the chip id of the Nigerian eID Card in the specified CardTerminal
	 * @throws ChannelException
	 */
	public String readChipId() throws ChannelException {
		try(Exclusive excl = exclusive(false)) {
			byte[] encId = profile.getChipId().read();
			return Hex.encode(encId);
		}
	}
	
	EPkiUserPin ePkiUserPin = new EPkiUserPin(this);
	EPkiSoPin ePkiSoPin = new EPkiSoPin(this);
	EIdPin eIdPin = new EIdPin(this);
	EIdPuk eIdPuk = new EIdPuk(this);
	
	BasePin[] pins = new BasePin[] {
		ePkiUserPin, ePkiSoPin, eIdPin, eIdPuk
	};
	
	Fingerprint leftThumb = new Fingerprint(this, profile.getLeftThumb());
	Fingerprint leftPointer = new Fingerprint(this, profile.getLeftPointer());
	Fingerprint leftMiddle = new Fingerprint(this, profile.getLeftMiddle());
	Fingerprint leftRing = new Fingerprint(this, profile.getLeftRing());
	Fingerprint leftLittle = new Fingerprint(this, profile.getLeftLittle());
	Fingerprint rightThumb = new Fingerprint(this, profile.getRightThumb());
	Fingerprint rightPointer = new Fingerprint(this, profile.getRightPointer());
	Fingerprint rightMiddle = new Fingerprint(this, profile.getRightMiddle());
	Fingerprint rightRing = new Fingerprint(this, profile.getRightRing());
	Fingerprint rightLittle = new Fingerprint(this, profile.getRightLittle());
	
	Fingerprint[] fingerprints = new Fingerprint[]{
		leftThumb,
		leftPointer,
		leftMiddle,
		leftRing,
		leftLittle,
		rightThumb,
		rightPointer,
		rightMiddle,
		rightRing,
		rightLittle
	};

	long determineAccess(EIdRequest req) {
		long access = 0L;
		if(req.readHolderName)
			access |= profile.getEIdDg1().ra();
		if(req.readCurrentAddress)
			access |= profile.getEIdDg2().ra();
		if(req.writeCurrentAddress)
			access |= profile.getEIdDg2().wa();
		if(req.readCurrentAddress && req.writeCurrentAddress)
			logger.debug("read and write address at the same time");
		if(req.readHeight)
			access |= profile.getEIdDg3().ra();
		if(req.readCountryOfBirth)
			access |= profile.getEIdDg4().ra();
		if(req.readNationality)
			access |= profile.getEIdDg5().ra();
		if(req.readIssuingDate)
			access |= profile.getEIdDg6().ra();
		if(req.readNIN)
			access |= profile.getEIdDg7().ra();
		if(req.readDateOfBirth)
			access |= profile.getEIdDg8().ra();
		if(req.readDocumentNumber)
			access |= profile.getEIdDg9().ra();
		
		return access;
	}
	

	/**
	 * This method fills up the internal {@link com.c10n.scalibur.profile.EacV2} object with all certificates and credentials, which 
	 * are required to perform the EACv2 protocol. This method has to be invoked, before a request can be performed successfully. 
	 * It is not required to invoke this to perform PIN operations on eID pins! If you only have to submit the DV certificates, 
	 * you can use something like Collections.singletonList(dvCert) to easily create a collection for it. Further, you can use
	 * the methods {@link SCalibur}.{@link com.c10n.scalibur.SCalibur#loadCertificate(File) loadCertificate()} and {@link SCalibur}.{@link com.c10n.scalibur.SCalibur#loadCertificates(File) loadCertificates()} to easily load certificates
	 * from files and submit them here.
	 * @param paConfig a PaConfig-object, constructed via {@link com.c10n.scalibur.tr3110.PaConfigBuilder}. Contains all certificates required for PA (passive authentication).
	 * @param tki the terminal's private key, stored in an implementation of AbstractTerminalKey. 
	 * @param taCert the terminal certificate, which belongs to the terminal's private key.
	 * @param certificates a collection of certificates, containing the DV certificate, which signed the terminal certificate and all CVCA link certificates.
	 * @see #request(EIdRequest, PinCallback)
	 * @see com.c10n.scalibur.SCalibur
	 * @see com.c10n.scalibur.SCalibur#loadCertificate(java.io.File)
	 * @see com.c10n.scalibur.SCalibur#loadCertificates(java.io.File)
	 */
	public void setEIdEacConfig(PaConfig paConfig, AbstractTerminalKey tki, CVCertificate taCert, Collection<CVCertificate> certificates) {
		profile.getEIdEac().setPAConfig(paConfig);
		profile.getEIdEac().setTACredentials(tki, taCert, certificates);
	}
	
	DataGroupCodec codec = new DataGroupCodec();
	
	void readWrite(EIdRequest req) {
		if(req.readHolderName) {
			try {
				byte[] enc = profile.getEIdDg1().read();
				req.holderName = codec.parseName(enc);
			} catch (Exception e) {
				logger.warn("read HolderName failed",e);
				req.readHolderNameError = e;
			}
		}
		Address currentAddress = req.currentAddress;
		if(req.readCurrentAddress) {
			try {
				byte[] enc = profile.getEIdDg2().read();
				req.currentAddress = codec.parseCurrentAddress(enc);
			} catch (Exception e) {
				logger.warn("read CurrentAddress failed",e);				
				req.readCurrentAddressError = e;
			}
		}
		if(req.readHeight) {
			try {
				byte[] enc = profile.getEIdDg3().read();
				req.height = codec.parseHeight(enc);
			} catch (Exception e) {
				logger.warn("read Height failed",e);				
				req.readHeightError = e;
			}
		}
		if(req.readCountryOfBirth) {
			try {
				byte[] enc = profile.getEIdDg4().read();
				req.countryOfBirth = codec.parseCountryOfBirth(enc);
			} catch (Exception e) {
				logger.warn("read CountryOfBirth failed",e);				
				req.readCountryOfBirthError = e;
			}
		}
		if(req.readNationality) {
			try {
				byte[] enc = profile.getEIdDg5().read();
				req.nationality = codec.parseNationality(enc);
			} catch (Exception e) {
				logger.warn("read Nationality failed",e);				
				req.readNationalityError = e;
			}
		}
		if(req.readIssuingDate) {
			try {
				byte[] enc = profile.getEIdDg6().read();
				req.issuingDate = codec.parseIssuingDate(enc);
			} catch (Exception e) {
				logger.warn("read IssuingDate failed",e);				
				req.readIssuingDateError = e;
			}
		}
		if(req.readNIN) {
			try {
				byte[] enc = profile.getEIdDg7().read();
				req.nIN = codec.parseNIN(enc);
			} catch (Exception e) {
				logger.warn("read NIN failed",e);				
				req.readNINError = e;
			}
		}
		if(req.readDateOfBirth) {
			try {
				byte[] enc = profile.getEIdDg8().read();
				req.dateOfBirth = codec.parseDateOfBirth(enc);
			} catch (Exception e) {
				logger.warn("read DateOfBirth failed",e);				
				req.readDateOfBirthError = e;
			}
		}
		if(req.readDocumentNumber) {
			try {
				byte[] enc = profile.getEIdDg9().read();
				req.documentNumber = codec.parseDocumentNumber(enc);
			} catch (Exception e) {
				logger.warn("read DocumentNumber failed",e);
				req.readDocumentNumberError = e;
			}
		}
		if(req.writeCurrentAddress) {
			try {
				byte [] enc = codec.encodeCurrentAddress(currentAddress);
				profile.getEIdDg2().write(enc);
			} catch (Exception e) {
				logger.warn("write CurrentAddress failed",e);
				req.writeCurrentAddressError = e;
			}			
		}		
	}
	
	/**
	 * Performs an EIdRequest with the Nigerian eID Card. Requires card communication. 
	 * Note that {@link #setEIdEacConfig(PaConfig, AbstractTerminalKey, CVCertificate, Collection)}
	 * has to be invoked first, since the request requires to perform the EACv2 protocol.
	 * The {@link com.c10n.scalibur.ngeid.card.EIdRequest} contains the 
	 * specification of which data groups should be read and which should be written. 
	 * After the method-invocation it also contains the read data. The 
	 * {@link PinCallback} asks for the eID PIN to be entered, 
	 * which is required to perform PACE as part of EACv2.
	 * @param request the {@link com.c10n.scalibur.ngeid.card.EIdRequest}, 
	 * specifying what should be read and written. On return it holds the read data.
	 * @param pinCb a {@link PinCallback} for the eID PIN.
	 * @see #setEIdEacConfig(PaConfig, AbstractTerminalKey, CVCertificate, Collection)
	 */
	public void request(EIdRequest request, PinCallback pinCb) throws SCaliburException {
		try {
			profile.getEIdEac().getTKI().prepareSigning();
		} catch (TkiException e) {
			logger.error("collecting TKI credentials failed", e);
			throw new SCaliburException("collecting TKI credentials failed",e);
		}
		try(Exclusive excl = exclusive(true)) {			
			long access = determineAccess(request);
			if(isUseSpe() && profile.getEIdEac().getSpe().isSupported()) {
				profile.getEIdEac().getSpe().authenticate(PacePinType.PIN, access);
				readWrite(request);
			} else {
				excl.end(false);
				try(
					PinValue pin = pinCb.getPin();
				) {
					excl.begin(true);
					profile.getEIdEac().authenticate(PacePinType.PIN, pin.getValue(), access);
					readWrite(request);
				}			
			}
		} catch (RuntimeException | SCaliburException e) {
			throw e;
		} catch (Exception e) {
			throw new SCaliburException(e);
		} finally {
			profile.getEIdEac().getTKI().clearCredentials();
		}
	}

	/**
	 * @return a handle to the ePKI User PIN
	 * @see #getPins()
	 */
	public EPkiUserPin getEPkiUserPin() {
		return ePkiUserPin;
	}

	/**
	 * @return a handle to the ePKI SO PIN
	 * @see #getPins()
	 */
	public EPkiSoPin getEPkiSoPin() {
		return ePkiSoPin;
	}

	/**
	 * @return a handle to the eID PIN
	 * @see #getPins()
	 */
	public EIdPin getEIdPin() {
		return eIdPin;
	}

	/**
	 * @return a handle to the eID PUK
	 * @see #getPins()
	 */
	public EIdPuk getEIdPuk() {
		return eIdPuk;
	}

	/**
	 * Returns an array of all Pin objects. The order is: ePKI User PIN, ePki SO PIN, eId PIN, eId PUK
	 * @return the array of Pin objects.
	 * 
	 * @see #getEIdPin()
	 * @see #getEIdPuk()
	 * @see #getEPkiUserPin()
	 * @see #getEPkiSoPin()
	 */
	public BasePin[] getPins() {
		return pins;
	}

	/**
	 * 
	 * @return the {@link Fingerprint} object, associated with the left thumb 
	 * @see #getFingerprints()
	 */
	public Fingerprint getLeftThumb() {
		return leftThumb;
	}

	/**
	 * 
	 * @return the {@link Fingerprint} object, associated with the left pointer finger
	 * @see #getFingerprints()
	 */
	public Fingerprint getLeftPointer() {
		return leftPointer;
	}
	
	/**
	 * 
	 * @return the {@link Fingerprint} object, associated with the left middle finger
	 * @see #getFingerprints()
	 */
	public Fingerprint getLeftMiddle() {
		return leftMiddle;
	}

	/**
	 * 
	 * @return the {@link Fingerprint} object, associated with the left ring finger
	 * @see #getFingerprints()
	 */
	public Fingerprint getLeftRing() {
		return leftRing;
	}

	/**
	 * 
	 * @return the {@link Fingerprint} object, associated with the left little finger
	 * @see #getFingerprints()
	 */
	public Fingerprint getLeftLittle() {
		return leftLittle;
	}

	/**
	 * 
	 * @return the {@link Fingerprint} object, associated with the right thumb
	 * @see #getFingerprints()
	 */
	public Fingerprint getRightThumb() {
		return rightThumb;
	}

	/**
	 * 
	 * @return the {@link Fingerprint} object, associated with the right pointer finger
	 * @see #getFingerprints()
	 */
	public Fingerprint getRightPointer() {
		return rightPointer;
	}

	/**
	 * 
	 * @return the {@link Fingerprint} object, associated with the right middle finger
	 * @see #getFingerprints()
	 */
	public Fingerprint getRightMiddle() {
		return rightMiddle;
	}

	/**
	 * 
	 * @return the {@link Fingerprint} object, associated with the right ring finger
	 * @see #getFingerprints()
	 */
	public Fingerprint getRightRing() {
		return rightRing;
	}

	/**
	 * 
	 * @return the {@link Fingerprint} object, associated with the right little finger
	 * @see #getFingerprints()
	 */
	public Fingerprint getRightLittle() {
		return rightLittle;
	}

	/**
	 * returns an array of all ten fingerprint objects. The order is:
	 * left Thumb, left Pointer, left Middle, left Ring, left Little,
	 * right Thumb, right Pointer, right Middle, right Ring, right Little
	 * 
	 * @return the array of {@link Fingerprint} objects.
	 * @see #getLeftThumb()
	 * @see #getLeftPointer()
	 * @see #getLeftMiddle()
	 * @see #getLeftRing()
	 * @see #getLeftLittle()
	 * 
	 * @see #getRightThumb()
	 * @see #getRightPointer()
	 * @see #getRightMiddle()
	 * @see #getRightRing()
	 * @see #getRightLittle()
	 */
	public Fingerprint[] getFingerprints() {
		return fingerprints;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setReader(CardTerminal terminal) throws ChannelException{
		super.setReader(terminal);
	}
}
