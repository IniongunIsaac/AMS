/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.card;

import com.c10n.scalibur.card.fp.ExistenceTester;
import com.c10n.scalibur.card.fp.HasExistenceTester;
import com.c10n.scalibur.card.fp.HasRetryCounterReader;
import com.c10n.scalibur.card.fp.RetryCounterReader;
import com.c10n.scalibur.card.fp.HasVerifier;
import com.c10n.scalibur.card.fp.Verifier;
import com.c10n.scalibur.card.pin.Composite;
import com.c10n.scalibur.ngeid.card.fp.HasPukResetter;
import com.c10n.scalibur.ngeid.card.fp.PukResetter;
import com.c10n.scalibur.profile.Pin;

/**
 * Fingerprint class for {@link NGeIDCard NGeIDCards}. Can be checked for existence,
 * verified with Match On Card and reset / reenrolled with the ePKI SO PIN.
 * @see NGeIDCard
 */
public class Fingerprint extends Composite<NGeIDCard, com.c10n.scalibur.ngeid.profile.Fingerprint> implements HasVerifier, HasRetryCounterReader, HasPukResetter, HasExistenceTester {

	protected Fingerprint(NGeIDCard ctx, com.c10n.scalibur.ngeid.profile.Fingerprint fp) {
		super(ctx, fp);
		Pin puk =  ctx.getProfile().getEPkiSoPin();
		pukResetter = new PukResetter(ctx, fp, puk){};
	}
	
	PukResetter pukResetter = null;
	RetryCounterReader retryCounterReader = new RetryCounterReader(ctx, base){};
	Verifier verifier = new Verifier(ctx, base){};
	ExistenceTester tester = new ExistenceTester(ctx, base){};

	@Override
	public PukResetter getPukResetter() {
		return pukResetter;
	}

	@Override
	public RetryCounterReader getRetryCounterReader() {
		return retryCounterReader;
	}

	@Override
	public Verifier getVerifier() {
		return verifier;
	}
	
	public com.c10n.scalibur.ngeid.profile.Fingerprint getProfileFingerprint() {
		return base;
	}
	
	public int getMaxMinutiae() {
		return base.getMaxMinutiae();
	}

	@Override
	public ExistenceTester getExistenceTester() {
		return tester;
	}
}
