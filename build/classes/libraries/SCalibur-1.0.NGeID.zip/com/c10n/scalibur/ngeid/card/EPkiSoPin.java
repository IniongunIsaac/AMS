/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.card;

import com.c10n.scalibur.card.BasePin;
import com.c10n.scalibur.card.pin.HasChanger;
import com.c10n.scalibur.card.pin.Changer;
import com.c10n.scalibur.card.pin.HasRetryCounterReader;
import com.c10n.scalibur.card.pin.HasVerifier;
import com.c10n.scalibur.card.pin.RetryCounterReader;
import com.c10n.scalibur.card.pin.Verifier;


/**
 * The ePKI SO PIN of the {@link NGeIDCard Nigerian eID Card} is a ISO PIN. It can be
 * verified and changed. These 
 * operations use {@link com.c10n.scalibur.card.pin.PinCallback PinCallbacks}. 
 * The ePKI SO PIN is blocked, if its {@link RetryCounterReader} is decreased to zero. Note, 
 * that there is no way to resume it if it is once blocked. In addition, it has a usage counter for
 * unblocking the ePKI User PIN! An attempt to verify (or change) it with a wrong 
 * pin value decreases this counter, while 
 * a successful attempt resets the counter to five. The PIN further has
 * Secure Pin Entry capabilities, which are going to be used, if the card is in
 * an appropriate card reader. 
 * The PinHandling_CardLayer example shows in a rather
 * detailed fashion some possible use cases of the ePKI SO PIN.
 * @see NGeIDCard
 * @see EPkiUserPin
 * @see com.c10n.scalibur.card.pin.PinCallback  
 */
public class EPkiSoPin extends BasePin implements HasRetryCounterReader, HasChanger, HasVerifier{
	protected EPkiSoPin(NGeIDCard ctx) {
		super(ctx, ctx.getProfile().getEPkiSoPin());
	}

	RetryCounterReader retryCounterReader = new RetryCounterReader(ctx, base){};
	Changer changer = new Changer(ctx, base){};

	@Override
	public Changer getChanger() {
		return changer;
	}

	@Override
	public RetryCounterReader getRetryCounterReader() {
		return retryCounterReader;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Verifier getVerifier() {
		return super.getVerifier();
	}

}
