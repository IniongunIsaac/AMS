/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.profile;

import com.c10n.scalibur.ChannelException;
import com.c10n.scalibur.DetermineRetriesException;
import com.c10n.scalibur.PacePinType;
import com.c10n.scalibur.profile.CardPath;
import com.c10n.scalibur.profile.PaceSpe;
import com.c10n.scalibur.profile.ProfileContext;
import com.c10n.scalibur.profile.SpePacePin;
import com.c10n.scalibur.PinBlockedException;
import com.c10n.scalibur.PinSuspendedException;
import com.c10n.scalibur.WrongPinException;


/**
 * The class EIdPin is a specialization of SpePacePin, needed for NGeIDProfile.
 * It is necessary to specialize the class, because the Nigerian eID Card does not
 * have a CAN in its card profile. Therefore, the handling of the retry counter of 
 * its eID PIN differs from the usual behavior of PACE PIN objects slightly, since there is no
 * suspended-mode (which requires a CAN), for this PIN object in this card profile. 
 * Regarding its behavior, it does not differ from the one of SpePacePin.
 * 
 * @see NGeIDProfile
 */
public class EIdPin extends SpePacePin {

	EIdPin(ProfileContext ctx, CardPath path, PacePinType type, int minSize, int maxSize) {
		super(ctx, path, type, minSize, maxSize);
	}

	/**
	 * 
	 */
	@Override
	public void verify(char[] pin) throws ChannelException {
		try {
			super.verify(pin);
		} catch(WrongPinException e) {
			if(e.getRetries() > 0)
				throw new WrongPinException(e.getCause(), e.getRetries()-1);
			else 
				throw e;
		} catch(PinSuspendedException e) {
			throw new PinBlockedException(e.getCause());
		} catch (DetermineRetriesException e) {
			if(0<e.retries && Integer.MAX_VALUE>e.retries)
				e.retries--;
			throw e;
		}
	}
	
/******************************************************************************/	
/*                                                                            */
/* The following methods are only overridden to create nicer JavaDoc-Output   */
/* 2014/08/26, DHT                                                            */
/*                                                                            */	
/******************************************************************************/
	@Override
	public PaceSpe getSpe() {
		return super.getSpe();
	}

	@Override
	public void change(char[] oldPin, char[] newPin) throws ChannelException {
		super.change(oldPin, newPin);
	}
	
	@Override
	public void reset(char[] newPin) throws ChannelException {
		super.reset(newPin);
	}
	
	@Override
	public void unblock() throws ChannelException {
		super.unblock();
	}
	
	@Override
	public int readRetryCounter() throws ChannelException {
		return super.readRetryCounter();
	}
	
	@Override
	public int getMinSize() {
		return super.getMinSize();
	}
	
	@Override
	public int getMaxSize() {
		return super.getMaxSize();
	}
}
