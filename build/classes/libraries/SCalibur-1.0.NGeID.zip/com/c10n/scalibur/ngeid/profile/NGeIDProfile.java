/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.profile;

import javax.smartcardio.Card;

import com.c10n.scalibur.CanceledException;
import com.c10n.scalibur.ChannelException;
import com.c10n.scalibur.PacePinType;
import com.c10n.scalibur.profile.CardManangerCardPath;
import com.c10n.scalibur.profile.CardPath;
import com.c10n.scalibur.profile.ChipId;
import com.c10n.scalibur.profile.EacV2;
import com.c10n.scalibur.profile.SpeIsoPin;
import com.c10n.scalibur.profile.distributed.ClientProfile;
import com.c10n.scalibur.profile.distributed.EacV2Client;

/**
 * This class is the profile layer interface for the Nigerian eID Card.  
 * It enables users to work closer to the card than the class NGeIdCard and
 * is a good starting point to work on the profile layer. It can be used either 
 * as stand-alone component for non-distributed EACv2 operations or as client for 
 * distributed ones (Here, {@link NGeIDProfileRemote} can be used on the server side).  
 * This class is used in the following examples: PinHandling_ProfileLayer, EIDRead_ProfileLayer and
 * in the distributed example in the client side. 
 * 
 * @see NGeIDProfileBase
 * @see NGeIDProfileRemote
 * @see com.c10n.scalibur.ngeid.card.NGeIDCard
 */
public class NGeIDProfile extends NGeIDProfileBase implements ClientProfile {	

	/**
	 * this constructor generates an instance of NGeIdProfile. Note that it  does not link the 
	 * instance to a concrete Nigerian eID card. This must be done later via the {@link NGeIDProfileBase#setCard setCard()}-method, before
	 * any card communication is tried to be performed.
	 * @see com.c10n.scalibur.profile.Profile#setCard(javax.smartcardio.Card)
	 */
	public NGeIDProfile() {
	}

	/**
	 * this constructor is the primary way to generate an instance of NGeIdProfile.
	 * @param card refers to the card handler, which identifies the Nigerian eID card to communicate with.
	 */
	public NGeIDProfile(Card card) {
		setCard(card);
	}

	CardManangerCardPath cmPath = new CardManangerCardPath(this);
	
	SpeIsoPin EPkiUserPin = new SpeIsoPin(this, mfPath, false, 0x1A, 4, 10, (byte) 0xFF){};
	SpeIsoPin EPkiSoPin = new SpeIsoPin(this, mfPath, false, 0x1B, 4, 10, (byte) 0xFF){};
	
	EIdPin EIdPin = new EIdPin(this, mfPath, PacePinType.PIN, 4, 10);
	EIdPin EIdPuk = new EIdPin(this, mfPath, PacePinType.PUK, 4, 10);
		
	Fingerprint leftThumb = new Fingerprint(this, mfPath, 0x10);
	Fingerprint leftPointer = new Fingerprint(this, mfPath, 0x11);
	Fingerprint leftMiddle = new Fingerprint(this, mfPath, 0x12);
	Fingerprint leftRing = new Fingerprint(this, mfPath, 0x13);
	Fingerprint leftLittle = new Fingerprint(this, mfPath, 0x14);
	Fingerprint rightThumb = new Fingerprint(this, mfPath, 0x15);
	Fingerprint rightPointer = new Fingerprint(this, mfPath, 0x16);
	Fingerprint rightMiddle = new Fingerprint(this, mfPath, 0x17);
	Fingerprint rightRing = new Fingerprint(this, mfPath, 0x18);
	Fingerprint rightLittle = new Fingerprint(this, mfPath, 0x19);
	
	ChipId chipId = new ChipId(this, cmPath){};

	/**
	 * gives access to the card manager's card path.
	 * @return the card manager's card path.
	 */
	public CardPath getCmPath() {
		return cmPath;
	}

	/**
	 * gives access to the ePKI User PIN object.
	 */
	public SpeIsoPin getEPkiUserPin() {
		return EPkiUserPin;
	}

	/**
	 * gives access to the ePKI SO PIN object.
	 */
	public SpeIsoPin getEPkiSoPin() {
		return EPkiSoPin;
	}

	/**
	 * gives access to the eID PIN object.
	 */
	public EIdPin getEIdPin() {
		return EIdPin;
	}

	/**
	 * gives access to the eID PUK object.
	 */
	public EIdPin getEIdPuk() {
		return EIdPuk;
	}

	public Fingerprint getLeftThumb() {
		return leftThumb;
	}

	public Fingerprint getLeftPointer() {
		return leftPointer;
	}

	public Fingerprint getLeftMiddle() {
		return leftMiddle;
	}

	public Fingerprint getLeftRing() {
		return leftRing;
	}

	public Fingerprint getLeftLittle() {
		return leftLittle;
	}

	public Fingerprint getRightThumb() {
		return rightThumb;
	}

	public Fingerprint getRightPointer() {
		return rightPointer;
	}

	public Fingerprint getRightMiddle() {
		return rightMiddle;
	}

	public Fingerprint getRightRing() {
		return rightRing;
	}

	public Fingerprint getRightLittle() {
		return rightLittle;
	}

	public ChipId getChipId() {
		return chipId;
	}

	@Override
	public boolean isInstance() {
		try {
			eIdPath.select();
			return true;
		} catch (ChannelException e) {
			return false;
		}
	}
	
	EacV2 eIdEac = null; 

	/**
	 * gives access to the {@link EacV2}-instance of this card realization, 
	 * which can be used to perform the EACv2 protocol. 
	 */
	public EacV2 getEIdEac() {
		if(null == eIdEac){
			eIdEac = new EacV2(this, mfPath){};
		}
		return eIdEac;
	}
	
	EacV2Client distributedEIdEac = null;
	@Override
	public EacV2Client getDistributedEIdEac() {
		if(null == distributedEIdEac){
			distributedEIdEac =  new EacV2Client(this, mfPath){};
		}
		return distributedEIdEac;
	}
	/******************************************************************************/	
	/*                                                                            */
	/* The following methods are only overridden to create nicer JavaDoc-Output   */
	/* 2014/08/26, DHT                                                            */
	/*                                                                            */	
	/******************************************************************************/
		/**
		 * sets the card, which is communicated with. Calls {@link #fallback}. Note that {@link #fallback}
		 * resets secure messaging and therefore might alter the card's authentication state. 
		 * @param card the card to send APDUs to.
		 * @see #getCard
		 * @see #fallback
		 */
		@Override 
		public void setCard(Card card){
			super.setCard(card);
		}
		
		/**
		 * gives access to the card, which is currently communicated with. This card can be
		 * changed with {@link #setCard}.
		 * @return the card to send APDUs to.
		 * @see #setCard
		 */
		@Override 
		public Card getCard() {
			return super.getCard();
		}
		
		@Override
		public void fallback(){ 
			super.fallback();
		}

		
		// copied from Profile. If not, the commant is copied from there
		// by JavaDoc, which leads to all links pointing to profile.method() (which is not
		// part of the javadoc) instead of NGeIDProfile.method().
		/**
		 * calling cancel cancels the current or next APDU from being sent to the card
		 * (which will trigger a {@link CanceledException}). Calling {@link #fallback()}
		 * overwrites this (i.e. calling {@link #cancel()} first and then {@link #fallback()} without transmitting an APDU in between ensures, that
		 * the next APDU will not trigger a {@link CanceledException}) due to the first {@link #cancel()}-call).
		 * @see #fallback()
		 * @see CanceledException
		 */
		@Override
		public void cancel() {
			super.cancel();
		}
}
