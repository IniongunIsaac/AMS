/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.profile;

import com.c10n.scalibur.ChannelException;
import com.c10n.scalibur.profile.AidCardPath;
import com.c10n.scalibur.profile.CardPath;
import com.c10n.scalibur.profile.Profile;

/**
 * This class is the base class for the profile layer interface for the Nigerian eID Card.  
 * It is not intended to be used directly, but it contains the common parts of 
 * {@link NGeIDProfile} and {@link NGeIDProfileRemote}.
 * Content of the data groups might be parsed using {@link com.c10n.scalibur.ngeid.card.DataGroupCodec}, 
 * as exemplified in the EIDRead_ProfileLayer example.
 * 
 * @see NGeIDProfile
 * @see NGeIDProfileRemote
 * @see com.c10n.scalibur.ngeid.card.DataGroupCodec
 */
public class NGeIDProfileBase extends Profile {	
	protected NGeIDProfileBase() {
	}
	
	AidCardPath mfPath = new AidCardPath(this, new byte[] {(byte) 0xD2, 0x76, 0x00, 0x00, (byte) 0x98, 0x01});
	AidCardPath eIdPath = new AidCardPath(this, new byte[] {(byte) 0xA0, 0x00, 0x00, 0x05, (byte) 0x78, 0x10, 0x01});
	
	ReadableDG eIdDg1 = new ReadableDG(this, eIdPath, 1){};
	ReadWriteDG eIdDg2 = new ReadWriteDG(this, eIdPath, 2){};
	ReadableDG eIdDg3 = new ReadableDG(this, eIdPath, 3){};
	ReadableDG eIdDg4 = new ReadableDG(this, eIdPath, 4){};
	ReadableDG eIdDg5 = new ReadableDG(this, eIdPath, 5){};
	ReadableDG eIdDg6 = new ReadableDG(this, eIdPath, 6){};
	ReadableDG eIdDg7 = new ReadableDG(this, eIdPath, 7){};
	ReadableDG eIdDg8 = new ReadableDG(this, eIdPath, 8){};
	ReadableDG eIdDg9 = new ReadableDG(this, eIdPath, 9){};
	
	/**
	 * gives access to the MF card path.
	 * @return the MF card path.
	 */
	public CardPath getMfPath() {
		return mfPath;
	}

	/**
	 * gives access to the eID application's card path.
	 * @return the eID application's card path.
	 */
	public CardPath getEIdPath() {
		return eIdPath;
	}
	
	/**
	 * gives access to data group 1 (name).
	 * @return the {@link ReadableDG} of data group 1.
	 */
	public ReadableDG getEIdDg1() {
		return eIdDg1;
	}

	/**
	 * gives access to data group 2 (current address).
	 * @return the {@link ReadWriteDG} of data group 2.
	 */
	public ReadWriteDG getEIdDg2() {
		return eIdDg2;
	}

	/**
	 * gives access to data group 3 (height).
	 * @return the {@link ReadableDG} of data group 3.
	 */
	public ReadableDG getEIdDg3() {
		return eIdDg3;
	}

	/**
	 * gives access to data group 4 (country of birth).
	 * @return the {@link ReadableDG} of data group 4.
	 */
	public ReadableDG getEIdDg4() {
		return eIdDg4;
	}

	/**
	 * gives access to data group 5 (nationality).
	 * @return the {@link ReadableDG} of data group 5.
	 */
	public ReadableDG getEIdDg5() {
		return eIdDg5;
	}

	/**
	 * gives access to data group 6 (issuing data).
	 * @return the {@link ReadableDG} of data group 6.
	 */
	public ReadableDG getEIdDg6() {
		return eIdDg6;
	}

	/**
	 * gives access to data group 7 (NIN).
	 * @return the {@link ReadableDG} of data group 7.
	 */
	public ReadableDG getEIdDg7() {
		return eIdDg7;
	}

	/**
	 * gives access to data group 8 (date of birth).
	 * @return the {@link ReadableDG} of data group 8.
	 */
	public ReadableDG getEIdDg8() {
		return eIdDg8;
	}

	/**
	 * gives access to data group 9 (document number).
	 * @return the {@link ReadableDG} of data group 9 .
	 */
	public ReadableDG getEIdDg9() {
		return eIdDg9;
	}

	/**
	 * checks, if the currently set card is indeed a Nigerian eID Card. Rather 
	 * useful for identification of smart cards in readers. Use {@link #setCard(javax.smartcardio.Card) setCard(..)}
	 * beforehand to set the card, which is going to be tested. Requires card communication.
	 * @see #setCard(javax.smartcardio.Card)
	 */
	@Override
	public boolean isInstance() {
		try {
			getEIdPath().select();
			return true;
		} catch (ChannelException e) {
			return false;
		}
	}
}
