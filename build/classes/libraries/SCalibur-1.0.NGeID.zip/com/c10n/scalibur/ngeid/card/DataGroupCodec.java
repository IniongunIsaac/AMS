/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.card;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import com.c10n.asn1.ASN1Exception;
import com.c10n.asn1.encoder.DEREncoder;
import com.c10n.asn1.ngeid.DG1;
import com.c10n.asn1.ngeid.DG2;
import com.c10n.asn1.ngeid.DG3;
import com.c10n.asn1.ngeid.DG4;
import com.c10n.asn1.ngeid.DG5;
import com.c10n.asn1.ngeid.DG6;
import com.c10n.asn1.ngeid.DG7;
import com.c10n.asn1.ngeid.DG8;
import com.c10n.asn1.ngeid.DG9;
import com.c10n.asn1.ngeid.NIMCAddress;
import com.c10n.asn1.parser.BERParser;
import com.c10n.asn1.universal.ASN1Integer;
import com.c10n.asn1.universal.NumericString;
import com.c10n.asn1.universal.PrintableString;
import com.c10n.asn1.universal.UTF8String;
import com.c10n.scalibur.EncodingException;
import com.c10n.scalibur.ngeid.card.EIdRequest.Address;
import com.c10n.scalibur.ngeid.card.EIdRequest.Name;

/**
 * The class DataGroupCodec is a helper class to parse and encode the content
 * of data groups of {@link NGeIDCard Nigerian eID Cards}. It offers a parse-method
 * for each readable data group, which takes the encoded byte array (read from the card)<br>
 * and returns the data in readable form and an {@link #encodeCurrentAddress encode-method}
 * for the current-address, which is the inverse of its {@link #parseCurrentAddress parse-method}.
 * Note, that DG2, the currentAddress is the only writable data group, which obsoletes 
 * additional write-methods.<br>To see an example use of this class see the EIDRead_ProfileLayer
 * example. Note that - although living on Card-Layer-API - this class might almost always be used
 * in Profile-Layer context, because Card-Layer internally already parses<br>the data groups, which
 * Profile-Layer does not.
 * 
 * @see com.c10n.scalibur.ngeid.profile.NGeIDProfile
 * @see Address
 * @see Name
 */
public class DataGroupCodec {

	String getOptString(Object val) throws UnsupportedEncodingException{
		if(null == val)
			return null;
		return val.toString();
	}

	Integer getOptInt(ASN1Integer val) throws UnsupportedEncodingException, ASN1Exception{
		if(null == val)
			return null;
		return val.getInt();
	}

	UTF8String getOptUTF8String(String val) throws UnsupportedEncodingException, ASN1Exception{
		if(null == val)
			return null;
		return new UTF8String(val);
	}

	public Name parseName(byte[] enc) throws EncodingException{
		try {
			DG1 dg = BERParser.parse(DG1.class, enc);
			Name name = new EIdRequest.Name();
			name.firstName = getOptString(dg.holderName.firstName);
			name.middleName = getOptString(dg.holderName.middleName);
			name.lastName = getOptString(dg.holderName.lastName);
			return name;
		} catch (IOException | ASN1Exception e) {
			throw new EncodingException("unable to parse name",e);
		}
	}

	public Address parseCurrentAddress(byte[] enc) throws EncodingException{
		try {
			DG2 dg = BERParser.parse(DG2.class, enc);
			Address currentAddress = new EIdRequest.Address();
			currentAddress.addressLine1 = getOptString(dg.currentAddress.addressLine1);
			currentAddress.addressLine2 = getOptString(dg.currentAddress.addressLine2);
			currentAddress.town = getOptString(dg.currentAddress.town);
			currentAddress.postcode = getOptString(dg.currentAddress.postcode);
			return currentAddress;
		} catch (IOException | ASN1Exception e) {
			throw new EncodingException("unable to parse current address",e);
		}
	}
	
	public byte[] encodeCurrentAddress(Address currentAddress)throws EncodingException{
		try {
			DG2 dg = new DG2();
			dg.currentAddress = new NIMCAddress();
			dg.currentAddress.addressLine1 = getOptUTF8String(currentAddress.addressLine1);
			dg.currentAddress.addressLine2 = getOptUTF8String(currentAddress.addressLine2);
			dg.currentAddress.town = getOptUTF8String(currentAddress.town);
			dg.currentAddress.postcode = getOptUTF8String(currentAddress.postcode);
			return DEREncoder.encode(dg);
		} catch (IOException | ASN1Exception e) {
			throw new EncodingException("unable to encode current address",e);
		}
	}

	public int parseHeight(byte[] enc) throws EncodingException{
		try {
			DG3 dg = BERParser.parse(DG3.class, enc);
			ASN1Integer height = dg.height;
			return getOptInt(height);
		} catch (IOException | ASN1Exception e) {
			throw new EncodingException("unable to parse height",e);
		}
	}
	
	public String parseCountryOfBirth(byte[] enc) throws EncodingException{
		try {
			DG4 dg = BERParser.parse(DG4.class, enc);
			PrintableString cob = dg.countryOfBirth;
			return getOptString(cob);
		} catch (IOException | ASN1Exception e) {
			throw new EncodingException("unable to parse country of birth",e);
		}
	}
	
	public String parseNationality(byte[] enc) throws EncodingException{
		try {
			DG5 dg = BERParser.parse(DG5.class, enc);
			PrintableString cob = dg.nationality;
			return getOptString(cob);
		} catch (IOException | ASN1Exception e) {
			throw new EncodingException("unable to parse nationality",e);
		}
	}
	
	public String parseIssuingDate(byte[] enc) throws EncodingException{
		try {
			DG6 dg = BERParser.parse(DG6.class, enc);
			NumericString date = dg.issuingDate;
			return getOptString(date);
		} catch (IOException | ASN1Exception e) {
			throw new EncodingException("unable to parse issuing date",e);
		}
	}
	
	public String parseNIN(byte[] enc) throws EncodingException{
		try {
			DG7 dg = BERParser.parse(DG7.class, enc);
			UTF8String nin = dg.nIN;
			return getOptString(nin);
		} catch (IOException | ASN1Exception e) {
			throw new EncodingException("unable to parse NIN",e);
		}
	}

	public String parseDateOfBirth(byte[] enc) throws EncodingException{
		try {
			DG8 dg = BERParser.parse(DG8.class, enc);
			NumericString dob = dg.dateOfBirth;
			return getOptString(dob);
		} catch (IOException | ASN1Exception e) {
			throw new EncodingException("unable to parse date of birth",e);
		}
	}
	
	public String parseDocumentNumber(byte[] enc) throws EncodingException{
		try {
			DG9 dg = BERParser.parse(DG9.class, enc);
			UTF8String docNum = dg.documentNumber;
			return getOptString(docNum);
		} catch (IOException | ASN1Exception e) {
			throw new EncodingException("unable to parse date of birth",e);
		}
	}
}
