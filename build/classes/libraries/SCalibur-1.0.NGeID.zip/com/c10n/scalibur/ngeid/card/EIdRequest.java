/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.card;


/**
 * This class forms the request of an eID Read operation.
 * First, data groups are selected for read (and write) operations, by setting 
 * the appropriate members to true. Then {@link NGeIDCard}.{@link NGeIDCard#request(EIdRequest, com.c10n.scalibur.card.pin.PinCallback) request(..)}
 * is invoked and afterwards the data and/or error messages can be extracted from the request.
 * The EIDRead_CardLayer example shows a simple case of this, while you can find all the 
 * flexibility in the SCalibur Offline Terminal example, including the update of
 * the currentAdress, which is the only data group of the {@link NGeIDCard Nigerian eID Card},
 * which can be updated.
 * @see NGeIDCard
 * @see NGeIDCard#request(EIdRequest, com.c10n.scalibur.card.pin.PinCallback)
 */
public class EIdRequest {
	//DG1
	/**
	 * Simple class, which holds all parts of a name, i.e. first, middle, and last Name.
	 */
	public static class Name {
		public String firstName;
		public String middleName;
		public String lastName;
		
		@Override
		public String toString() {
			return "Name [firstName=" + firstName + ", middleName="
					+ middleName + ", lastName=" + lastName + "]";
		}
	}
	public Name holderName;
	public boolean readHolderName;
	public Exception readHolderNameError;

	//DG2
	/**
	 * Simple class, which holds all parts of an address.
	 */
	public static class Address {
		public String addressLine1;
		public String addressLine2;
		public String town;
		public String postcode;
		
		@Override
		public String toString() {
			return "Address [addressLine1=" + addressLine1 + ", addressLine2="
					+ addressLine2 + ", town=" + town + ", postcode="
					+ postcode + "]";
		}
	}
	public Address currentAddress;
	public boolean readCurrentAddress;
	public Exception readCurrentAddressError;
	public boolean writeCurrentAddress;
	public Exception writeCurrentAddressError;	
	public Address newCurrentAddress() {
		currentAddress = new Address();
		return currentAddress;
	}
	
	//DG3
	public Integer height;
	public boolean readHeight;
	public Exception readHeightError;	
	
	//DG4
	public String countryOfBirth;
	public boolean readCountryOfBirth;
	public Exception readCountryOfBirthError;	
	
	//DG5
	public String nationality;
	public boolean readNationality;
	public Exception readNationalityError;	

	//DG6
	public String issuingDate;
	public boolean readIssuingDate;
	public Exception readIssuingDateError;	
	
	//DG7
	public String nIN;
	public boolean readNIN;
	public Exception readNINError;	
	
	//DG8
	public String dateOfBirth;
	public boolean readDateOfBirth;
	public Exception readDateOfBirthError;	

	//DG9
	public String documentNumber;
	public boolean readDocumentNumber;
	public Exception readDocumentNumberError;
	
	@Override
	public String toString() {
		return "EIdRequest [holderName=" + holderName + ", readHolderName="
				+ readHolderName + ", readHolderNameError="
				+ readHolderNameError + ", currentAddress=" + currentAddress
				+ ", readCurrentAddress=" + readCurrentAddress
				+ ", readCurrentAddressError=" + readCurrentAddressError
				+ ", writeCurrentAddress=" + writeCurrentAddress
				+ ", writeCurrentAddressError=" + writeCurrentAddressError
				+ ", height=" + height + ", readHeight=" + readHeight
				+ ", readHeightError=" + readHeightError + ", countryOfBirth="
				+ countryOfBirth + ", readCountryOfBirth=" + readCountryOfBirth
				+ ", readCountryOfBirthError=" + readCountryOfBirthError
				+ ", nationality=" + nationality + ", readNationality="
				+ readNationality + ", readNationalityError="
				+ readNationalityError + ", issuingDate=" + issuingDate
				+ ", readIssuingDate=" + readIssuingDate
				+ ", readIssuingDateError=" + readIssuingDateError + ", nIN="
				+ nIN + ", readNIN=" + readNIN + ", readNINError="
				+ readNINError + ", dateOfBirth=" + dateOfBirth
				+ ", readDateOfBirth=" + readDateOfBirth
				+ ", readDateOfBirthError=" + readDateOfBirthError
				+ ", documentNumber=" + documentNumber
				+ ", readDocumentNumber=" + readDocumentNumber
				+ ", readDocumentNumberError=" + readDocumentNumberError + "]";
	}
}
