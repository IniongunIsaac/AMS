/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.card;

import com.c10n.scalibur.card.BasePin;
import com.c10n.scalibur.card.pin.HasChanger;
import com.c10n.scalibur.card.pin.Changer;
import com.c10n.scalibur.card.pin.HasFingerprintResetter;
import com.c10n.scalibur.card.pin.FingerprintResetter;
import com.c10n.scalibur.card.pin.HasRetryCounterReader;
import com.c10n.scalibur.card.pin.HasVerifier;
import com.c10n.scalibur.card.pin.RetryCounterReader;
import com.c10n.scalibur.card.pin.HasUnblocker;
import com.c10n.scalibur.card.pin.Unblocker;
import com.c10n.scalibur.card.pin.Verifier;
import com.c10n.scalibur.profile.Pin;

/**
 * The ePKI User PIN of the {@link NGeIDCard Nigerian eID Card} is a ISO PIN. It can be
 * verified, changed and unblocked with the {@link EPkiSoPin ePKI SO PIN}. All these 
 * operations use {@link com.c10n.scalibur.card.pin.PinCallback PinCallbacks}. 
 * The ePKI User PIN is blocked, if its {@link RetryCounterReader} is decreased to zero. 
 * An attempt to verify (or change) it with a wrong pin value decreases this counter, while 
 * a successful attempt resets the counter to three. 
 * The ePKI User PIN can in addition be reset with a fingerprint verification!
 * The PIN further has
 * Secure Pin Entry capabilities, which are going to be used, if the card is in
 * an appropriate card reader. 
 * The PinHandling_CardLayer example shows in a rather
 * detailed fashion some possible use cases of the ePKI User PIN.
 * @see NGeIDCard
 * @see EPkiSoPin
 * @see com.c10n.scalibur.card.pin.PinCallback
 */
public class EPkiUserPin extends BasePin implements HasRetryCounterReader, HasChanger, HasUnblocker, HasFingerprintResetter, HasVerifier{
	protected EPkiUserPin(NGeIDCard ctx) {
		super(ctx, ctx.getProfile().getEPkiUserPin());
		Pin puk = ctx.getProfile().getEPkiSoPin();
		unblocker = new Unblocker(ctx, base ,puk){}; 
	}

	RetryCounterReader retryCounterReader = new RetryCounterReader(ctx, base){};
	Changer changer = new Changer(ctx, base){};
	Unblocker unblocker = null; 
	FingerprintResetter resetter = new FingerprintResetter(ctx, base){};

	@Override
	public Changer getChanger() {
		return changer;
	}
	@Override
	public Unblocker getUnblocker() {
		return unblocker;
	}
	@Override
	public FingerprintResetter getFingerprintResetter() {
		return resetter;
	}
	@Override
	public RetryCounterReader getRetryCounterReader() {
		return retryCounterReader;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Verifier getVerifier() {
		return super.getVerifier();
	}
}
