/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.card;

import com.c10n.scalibur.card.BasePin;
import com.c10n.scalibur.card.pin.HasVerifier;
import com.c10n.scalibur.card.pin.Verifier;

/**
 * The eID PUK of the {@link NGeIDCard Nigerian eID Card} is a PACE PIN. Its main
 * purpose is the unblocking of a blocked {@link EIdPin}. The eID PUK can be
 * verified, but there is no way to change it. There is also no way to unblock it, 
 * but it does not have a retry counter, so there is also no way of blocking it.
 * The {@link Verifier} use {@link com.c10n.scalibur.card.pin.PinCallback PinCallbacks}. The PIN further has
 * Secure Pin Entry capabilities, which are going to be used, if the card is in
 * an appropriate card reader. 
 * Note, that all operations on PACE PINs require the execution of PACE and create
 * an secure messaging. The PinHandling_CardLayer example shows in a rather
 * detailed fashion some possible use cases of the eID PIN.
 * @see NGeIDCard
 * @see EIdPin
 * @see com.c10n.scalibur.card.pin.PinCallback
 */
public class EIdPuk extends BasePin implements HasVerifier {
	protected EIdPuk(NGeIDCard ctx) {
		super(ctx, ctx.getProfile().getEIdPuk());
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Verifier getVerifier() {
		return super.getVerifier();
	}
}
