/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.card;

import com.c10n.scalibur.card.BasePin;
import com.c10n.scalibur.card.pin.HasChanger;
import com.c10n.scalibur.card.pin.Changer;
import com.c10n.scalibur.card.pin.HasPukResetter;
import com.c10n.scalibur.card.pin.HasVerifier;
import com.c10n.scalibur.card.pin.PukResetter;
import com.c10n.scalibur.card.pin.HasRetryCounterReader;
import com.c10n.scalibur.card.pin.RetryCounterReader;
import com.c10n.scalibur.card.pin.HasUnblocker;
import com.c10n.scalibur.card.pin.Unblocker;
import com.c10n.scalibur.card.pin.Verifier;
import com.c10n.scalibur.profile.Pin;

/**
 * The eID PIN of the {@link NGeIDCard Nigerian eID Card} is a PACE PIN. It can be
 * verified, changed and unblocked and reset with the {@link EIdPuk eID PUK}. All these 
 * operations use {@link com.c10n.scalibur.card.pin.PinCallback PinCallbacks}. 
 * The eID PIN is blocked, if its {@link RetryCounterReader} is decreased to zero. 
 * An attempt to verify (or change) it with a wrong pin value decreases this counter, while 
 * a successful attempt resets the counter to three. The PIN further has
 * Secure Pin Entry capabilities, which are going to be used, if the card is in
 * an appropriate card reader. 
 * Note, that all operations on PACE PINs require the execution of PACE and create
 * an secure messaging. The PinHandling_CardLayer example shows in a rather
 * detailed fashion some possible use cases of the eID PIN.
 * @see NGeIDCard
 * @see EIdPuk
 * @see com.c10n.scalibur.card.pin.PinCallback
 */
public class EIdPin extends BasePin implements HasRetryCounterReader, HasChanger, HasUnblocker, HasPukResetter, HasVerifier {
	protected EIdPin(NGeIDCard ctx) {
		super(ctx, ctx.getProfile().getEIdPin());
		
		Pin puk = ctx.getProfile().getEIdPuk();
		unblocker = new Unblocker(ctx, base, puk){}; 
		resetter = new PukResetter(ctx, base, puk){};
	}

	RetryCounterReader retryCounterReader = new RetryCounterReader(ctx, base, 3){};
	Changer changer = new Changer(ctx, base){};
	Unblocker unblocker = null; 
	PukResetter resetter = null;
	
	@Override
	public Changer getChanger() {
		return changer;
	}
	@Override
	public Unblocker getUnblocker() {
		return unblocker;
	}
	@Override
	public PukResetter getPukResetter() {
		return resetter;
	}
	@Override
	public RetryCounterReader getRetryCounterReader() {
		return retryCounterReader;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Verifier getVerifier() {
		return super.getVerifier();
	}
}
