/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.profile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.c10n.scalibur.ChannelException;
import com.c10n.scalibur.profile.CardPath;
import com.c10n.scalibur.profile.IsoFingerprint;
import com.c10n.scalibur.profile.ProfileContext;

/** 
 * is an adaption of {@link IsoFingerprint} to the Nigerian eID Card
 * Being more specific, it is able to determine, which finger
 * it belongs to, by knowing the corresponding authIds.
 * 
 * @see NGeIDProfile
 * @see com.c10n.scalibur.ngeid.card.NGeIDCard
 *
 */
public class Fingerprint extends IsoFingerprint {
	final Logger logger = LoggerFactory.getLogger(Fingerprint.class);

	int subType;
	public Fingerprint(ProfileContext ctx, CardPath path, int authId) {
		super(ctx, path, true, authId, 0x0C, 0x30);
		int pos = authId-0x10;
		if(pos < 5) { // left hand
			subType = (pos+1)<<2 | 2;
		} else { // right hand
			subType = (pos-4)<<2 | 1;
		}
	}

	/**
	 * resets / re-enrolls the fingerprint object on card. Implicitly unblocks a blocked
	 * fingerprint object.
	 * @param minutiae
	 * @throws ChannelException
	 */
	public void reset(byte[] minutiae) throws ChannelException {
		super.reset(minutiae, subType);
	}
	
	
	// We don't want to document IsoFingerprint, but the methods below should
	// be documented in public:
	/**
	 * {@inheritDoc}
	 */
	@Override
	public int readRetryCounter() throws ChannelException {
		return super.readRetryCounter();
	}
	
	// here inherit doc does not work, because we want the links to point to fingerprint
	// and not to isofingerprint:
	/**
	 * performs a match on card (MoC) operation. Requires card operation and an compact iso format 
	 * set of minutiae, which contains more than {@link #minMinutiae} and at most {@link #maxMinutiae}
	 * minutae. This method does alter the authentication status of the card, i.e. 
	 * you should reset the card, when the transaction is closed!
	 * @param minutiae
	 * @throws ChannelException
	 * @see #maxMinutiae
	 * @see #minMinutiae
	 */
	@Override
	public void verify(byte[] minutiae) throws ChannelException {
		super.verify(minutiae);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isExisting() throws ChannelException{
		return super.isExisting();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getMinMinutiae() {
		return super.getMinMinutiae();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getMaxMinutiae() {
		return super.getMaxMinutiae();
	}

}
