/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.profile;

import com.c10n.scalibur.ChannelException;
import com.c10n.scalibur.Commands;
import com.c10n.scalibur.Commands.FCI;
import com.c10n.scalibur.profile.CardPath;
import com.c10n.scalibur.profile.EacV2;
import com.c10n.scalibur.profile.ProfileContext;
/**
 * Profile Layer access to eID readable data groups of a smart card/ eID applicaton.
 *  Data groups are indexed by a number, which also references where to find the 
 *  group on the smart card. Usually, it is not required to instantiate this 
 *  class manually, because its instances come as part of a 
 *  {@link com.c10n.scalibur.profile.Profile}. 
 *  
 */
public class ReadableDG {
	ProfileContext ctx;
	CardPath path;
	int dg;

	protected ReadableDG(ProfileContext ctx, CardPath path, int dG) {
		this.ctx = ctx;
		this.path = path;
		this.dg = dG;
	}
		
	/**
	 * reads the binary content of the datagroup from the smart card. Requires 
	 * an established connection to the smart card with an appropriate 
	 * authentication status. Usually, this requires to establish an EACv2 secure 
	 * messaging beforehand, which can be done with {@link EacV2}. 
	 * @return the datagroups content
	 * @throws ChannelException
	 * @see EacV2
	 */
	public byte[] read() throws ChannelException {
		Commands cmds = ctx.getCommands();
		path.select();
		cmds.selectEF(0x0100 | dg, FCI.NONE);
		return cmds.readBinaryAll();
	}
	
	/**
	 * returns the chat bit(s) to read this datagroup.
	 * @return the required chat bit(s) to read this datagroup.
	 */
	public long ra() {
		return 1L << (dg+7);
	}
	
	/**
	 * returns the index of the datagroup.
	 * @return the datagroup's index.
	 */
	public int getDG() {
		return dg;
	}
}
