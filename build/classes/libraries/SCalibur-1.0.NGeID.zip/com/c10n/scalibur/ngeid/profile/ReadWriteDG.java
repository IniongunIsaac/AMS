/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.profile;

import com.c10n.scalibur.ChannelException;
import com.c10n.scalibur.Commands;
import com.c10n.scalibur.Commands.FCI;
import com.c10n.scalibur.profile.CardPath;
import com.c10n.scalibur.profile.EacV2;
import com.c10n.scalibur.profile.ProfileContext;

/**
 * Profile Layer access to eID datagroups, which can be read and written.
 *  Datagroups are indexed by a number, which also references where to find the 
 *  group on the smart card. Usually, it is not required to instantiate this 
 *  class manually, because its instances come as part of a 
 *  {@link com.c10n.scalibur.profile.Profile}.  
 */
public class ReadWriteDG extends ReadableDG {
	
	protected ReadWriteDG(ProfileContext ctx, CardPath path, int dG) {
		super(ctx, path, dG);
	}
	
	/**
	 * updates the datagroups content with the provided binary data. Note: this allows
	 * to store improper formatted data in the datagroup! To perform this operation
	 * successfully, a connection to the card with an appropriate 
	 * authentication status has to be established beforehand. Usually, this 
	 * requires to establish an EACv2 secure messaging, which can be done with 
	 * {@link EacV2}. 
	 * 
	 * @param data
	 * @throws ChannelException
	 */
	public void write(byte[] data) throws ChannelException {
		Commands cmds = ctx.getCommands();
		path.select();
		cmds.selectEF(0x0100 | dg, FCI.NONE);
		cmds.updateBinaryAll(data);
	}

	/**
	 * returns the chat bit(s) to read and write this datagroup. Note, the write 
	 * access always requires read access beforehand!
	 * @return the required chat bit(s) to read and write this datagroup.
	 */
	public long wa() {
		return (1L << (35L - dg)) | ra();
	}
}
