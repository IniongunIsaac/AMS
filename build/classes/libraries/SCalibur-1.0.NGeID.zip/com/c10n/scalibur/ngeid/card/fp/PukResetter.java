/******************************************************************************\
*                                                                              *
*                                       .,,::                                  *  
*            .;;:.               .:::::::::::                                  *  
*             ;;;;;;;        ::::::::::::::::                                  *  
*              ;;;;;;;;     .::::::::::::::::                                  *  
*              `;;;;;;;;;     ,::::::::::::::                                  *  
*                `;;;;;;;;;     ,:::::::::,,,                                  *  
*                  `;;;;;;;;;     ::,`                                         *  
*                    `;;;;;''';                                                *  
*                 :`   `;''''''';     `.,,:::::,,`                             *  
*                ::::`   `'''''''';    `::::::::::::,                          *  
*               .::::::`   `'''''''';    `::::::::::::,                        *  
* ..............:::::::::`    '''''''';    `:::::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::.     '''''''''    `:::::::::::::::::::::::::        *  
* ::::::::::::::::::::::::        ''''''++;    `:::::::::::::::::::::::        *  
* ::::::::::::::::::::::::    ,     ''++++++;    .:::::::::::::::::::::        *  
* :::::::::::::::::::::::,    :::     '+++++++;    .:::::::::::::::::::        *  
* ::::::::::::::::::::::::    ;;;;:     '+++++++:    .;;;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;     ;;;;;:     '+++++++:    ,;;;;;;;;;;;;;;;        *  
* ;;;;;;;;;;;;;;;;;;;;;;;;:     ;;;;;;:     '+++++++,    ,:::::::::::::        *  
*               ;;;;;;;;;;;.     ,;;;;;;:     '+++++++,                        *  
*               `;;;;;;;;;;;.      ,;;;;;;;     '+++++++,                      *  
*                ,;;;;;;;;;;;:        .;'''';     '+++++++,                    *  
*                 ,;;;;;;;;;;;;,                    '+++++++,       .::;;:,.   *  
*                  `;;;;;;;;;;;;;;,                   '+++++++,   ,;;'+++'     *  
*                    ;;;;;;;;;;;;;;;;;;,`               '+++++, ,;''+++;       *  
*                      ;;;;;;;;;;;;;;;;;;;;;;             '+. :;''+++;         *  
*                        :;;;;;;;;;;;;;;;;;;;               :;''+++,           *
*                           ;''''''''''''''''             ;;''+++, .;:         *  
*                              .;''''''''''''           ;;''+++. .;;;'':       *  
*                                   .:;''''''           ''+++`     ;''+++,     *  
* This file is part of SCalibur.                        ++'`         ;++; `,`  *  
*                                                       '               ,;'''+ *
* copyright: (c) 2014 - 2016 cv cryptovision GmbH, all rights reserved  ,''+++ *
*                                                                         ,:.  *
* license:  The conditions for the use of this software are regulated          *
* in the Software License Agreement for SCalibur.                              *
*                                                                              *
* The License Agreement should be included in this delivery,                   *
* if the License Agreement is not included please request it from              *
* our Website: http://www.cryptovision.com/                                    *
\******************************************************************************/



package com.c10n.scalibur.ngeid.card.fp;

import com.c10n.scalibur.SCaliburException;
import com.c10n.scalibur.card.AbstractCard;
import com.c10n.scalibur.card.AbstractCard.Exclusive;
import com.c10n.scalibur.card.fp.FingerprintCallback;
import com.c10n.scalibur.card.fp.FingerprintCallback.Minutiae;
import com.c10n.scalibur.card.fp.FingerprintOperation;
import com.c10n.scalibur.card.pin.IgnoreSpePinCallback;
import com.c10n.scalibur.card.pin.PinCallback;
import com.c10n.scalibur.card.pin.PinCallback.PinValue;
import com.c10n.scalibur.ngeid.profile.Fingerprint;
import com.c10n.scalibur.profile.Pin;
import com.c10n.scalibur.profile.Spe;

/**
 * allows to reset / re-enroll {@link com.c10n.scalibur.ngeid.card.Fingerprint Fingerprints}. Requires
 * the ePKI SO PIN to do so, besides minutiae.
 * 
 * @see com.c10n.scalibur.ngeid.card.Fingerprint
 * @see HasPukResetter
 */
public class PukResetter extends FingerprintOperation {
	Pin puk;
	Fingerprint base;
	
	protected PukResetter(AbstractCard ctx, Fingerprint fp, Pin puk) {
		super(ctx, fp);
		this.puk = puk;
		this.base = fp;
	}

	/**
	 * resets the {@link Fingerprint},
	 * this PukResetter belongs to. Resetting means that it unblocks and changes the reference data. 
	 * Requires card communication.
	 * @param fpCb FingerprintCallback to collect minutiae which replace the current
	 * minutiae on card. 
	 * @param pinCb PinCallback to collect the pin value of the ePKI SO PIN
	 * @throws SCaliburException
	 */
	public void reset(FingerprintCallback fpCb, PinCallback pinCb) throws SCaliburException {
		try(Exclusive excl = ctx.exclusive(false)) {
			Spe pukSpe = useSpe(puk);
			if( !(pinCb instanceof IgnoreSpePinCallback) &&
				null != pukSpe &&
				pukSpe.isVerifySupported()) {
				
				excl.end();
				try(
					Minutiae minutiae = fpCb.getMinutiae();
				) {
					excl.begin(true);
					pukSpe.verify();
					base.reset(minutiae.getValue());					
				}
			} else {
				excl.end();
				try(
					Minutiae minutiae = fpCb.getMinutiae();
					PinValue pinVal = pinCb.getPin()
				) {
					excl.begin(true);
					puk.verify(pinVal.getValue());
					base.reset(minutiae.getValue());					
				}
			}
		} catch (RuntimeException | SCaliburException e) {
			throw e;
		} catch (Exception e) {
			throw new SCaliburException(e);
		}

	}
}
